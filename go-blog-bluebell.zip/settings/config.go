package settings

import (
	"flag"
	"fmt"
	"time"

	"github.com/fsnotify/fsnotify"
	"github.com/spf13/viper"
)

var Conf = new(multipleConfig)

type multipleConfig struct {
	*AppConfig   `mapstructure:"app"`
	*LogConfig   `mapstructure:"log"`
	*MySQLConfig `mapstructure:"mysql"`
	*RedisConfig `mapstructure:"redis"`
	*OssConfig   `mapstructure:"oss"`
	*EmailConfig `mapstructure:"email"`
}

type AppConfig struct {
	Name             string        `mapstructure:"name"`
	Mode             string        `mapstructure:"mode"`
	Version          string        `mapstructure:"version"`
	Port             string        `mapstructure:"port"`
	StartTime        string        `mapstructure:"start_time"`
	PageNum          int64         `mapstructure:"page_num"`
	PageSize         int64         `mapstructure:"page_size"`
	MachineID        int64         `mapstructure:"machine_id"`
	JwtExpireTime    time.Duration `mapstructure:"jwt_expire_time"`
	UploadModel      string        `mapstructure:"uploadModel"`
	*PhotoPathConfig `mapstructure:"photoPath"`
}

type PhotoPathConfig struct {
	PhotoHost     string `mapstructure:"photoHost"`
	AvatarPath    string `mapstructure:"avatarPath"`
	DefaultAvatar string `mapstructure:"defaultAvatar"`
}

type LogConfig struct {
	Level      string `mapstructure:"level"`
	Filename   string `mapstructure:"filename"`
	MaxSize    int    `mapstructure:"max_size"`
	MaxAge     int    `mapstructure:"max_age"`
	MaxBackups int    `mapstructure:"max_backups"`
	FilePath   string `mapstructure:"filepath"`
}

type MySQLConfig struct {
	Host         string `mapstructure:"host"`
	User         string `mapstructure:"user"`
	Password     string `mapstructure:"password"`
	DbName       string `mapstructure:"dbname"`
	Port         string `mapstructure:"port"`
	MaxOpenConns int    `mapstructure:"max_open_conns"`
	MaxIdleConns int    `mapstructure:"max_idle_conns"`
}

type RedisConfig struct {
	Host     string `mapstructure:"host"`
	Password string `mapstructure:"password"`
	Port     string `mapstructure:"port"`
	DB       int    `mapstructure:"db"`
	PoolSize int    `mapstructure:"pool_size"`
}

type EmailConfig struct {
	ValidEmail          string        `mapstructure:"validEmail"`
	SmtpHost            string        `mapstructure:"smtpHost"`
	SmtpEmail           string        `mapstructure:"smtpEmail"`
	SmtpPass            string        `mapstructure:"smtpPass"`
	EmailCodeExpireTime time.Duration `mapstructure:"emailCodeExpireTime"`
	EmailCodeSaveTime   time.Duration `mapstructure:"emailCodeSaveTime"`
}

type OssConfig struct {
	AccessKeyId     string `mapstructure:"accessKeyId"`
	AccessKeySecret string `mapstructure:"accessKeySecret"`
	BucketName      string `mapstructure:"bucketName"`
	QiNiuServer     string `mapstructure:"qiNiuServer"`
}

// func InitSettings() (err error) {
// 	viper.SetConfigName("config")
// 	viper.SetConfigType("yaml")
// 	// viper.SetConfigFile("./config/config.yaml")
// 	viper.AddConfigPath("./config/")
// 	viper.AddConfigPath("./")
// 	err = viper.ReadInConfig()
// 	if err != nil {
// 		// 读取配置信息失败
// 		fmt.Printf("viper.ReadInConfig failed, err:%v\n", err)
// 		return
// 	}
// 	// 配置信息的反序列化
// 	if err := viper.Unmarshal(Conf); err != nil {
// 		fmt.Printf("viper Unmarshal failed, err:%v\n", err)
// 	}
// 	viper.WatchConfig()
// 	viper.OnConfigChange(func(in fsnotify.Event) {
// 		fmt.Println("配置文件被修改了")
// 		if err := viper.Unmarshal(Conf); err != nil {
// 			fmt.Printf("viper Unmarshal failed, err:%v\n", err)
// 		}
// 	})
// 	return
// }

func InitSettings() (err error) {
	// viper.SetConfigName("config")
	// viper.SetConfigType("yaml")
	// viper.SetConfigFile("./config/config.yaml")
	// viper.AddConfigPath("./config/")
	// viper.AddConfigPath("./")

	// viper.SetConfigFile(filePath)
	var filePath string
	flag.StringVar(&filePath, "filePath", "./config/config.yaml", "配置文件")
	//解析命令行参数
	flag.Parse()
	fmt.Println(filePath)
	fmt.Println(flag.Args())
	fmt.Println(flag.NArg())
	fmt.Println(flag.NFlag())
	viper.SetConfigFile(filePath)

	err = viper.ReadInConfig()
	if err != nil {
		// 读取配置信息失败
		fmt.Printf("viper.ReadInConfig failed, err:%v\n", err)
		return
	}
	// 配置信息的反序列化
	if err := viper.Unmarshal(Conf); err != nil {
		fmt.Printf("viper Unmarshal failed, err:%v\n", err)
	}
	viper.WatchConfig()
	viper.OnConfigChange(func(in fsnotify.Event) {
		fmt.Println("配置文件被修改了")
		if err := viper.Unmarshal(Conf); err != nil {
			fmt.Printf("viper Unmarshal failed, err:%v\n", err)
		}
	})
	return
}
